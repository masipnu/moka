  <!-- Main Footer -->
  <footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
      Made with <i class="fa fa-heart text-red" aria-hidden="true"></i> by : <b>masipnu</b>
    </div>
    <!-- Default to the left -->
    <!-- <strong>Copyright &copy; 2016 <a href="#">Company</a>.</strong> All rights reserved. -->

    <!-- Modif -->
    <strong>Copyright &copy; 2023 | <a href="#">SMK BP Subulul Huda</a></strong>
  </footer>