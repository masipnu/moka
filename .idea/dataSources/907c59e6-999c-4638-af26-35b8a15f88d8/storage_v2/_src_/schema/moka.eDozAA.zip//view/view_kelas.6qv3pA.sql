create definer = root@localhost view view_kelas as
select `moka`.`kelas`.`id_kelas`   AS `id_kelas`,
       `moka`.`kelas`.`nama_kelas` AS `nama_kelas`,
       `moka`.`komli`.`nama_komli` AS `nama_komli`,
       `moka`.`komli`.`prosentase` AS `prosentase`
from (`moka`.`kelas` left join `moka`.`komli` on ((`moka`.`kelas`.`id_komli` = `moka`.`komli`.`id_komli`)))
order by `moka`.`kelas`.`id_kelas`;

