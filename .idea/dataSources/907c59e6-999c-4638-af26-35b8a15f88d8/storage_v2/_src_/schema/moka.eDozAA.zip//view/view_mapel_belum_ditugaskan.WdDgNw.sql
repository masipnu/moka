create definer = root@localhost view view_mapel_belum_ditugaskan as
select `view_mapel`.`id_mapel`   AS `id_mapel`,
       `view_mapel`.`nama_mapel` AS `nama_mapel`,
       `view_mapel`.`nama_kelas` AS `nama_kelas`,
       `view_mapel`.`nama_komli` AS `nama_komli`
from `moka`.`view_mapel`
where (not (`view_mapel`.`id_mapel` in (select `moka`.`mengajar`.`id_mapel` from `moka`.`mengajar`)))
order by `view_mapel`.`nama_mapel`;

