create definer = root@localhost view view_guru_simple as
select `moka`.`guru`.`id_guru` AS `id_guru`, `moka`.`guru`.`nama` AS `nama_guru`, `moka`.`guru`.`gelar` AS `gelar`
from `moka`.`guru`
order by `moka`.`guru`.`id_guru`;

