create definer = root@localhost view view_jam_kbm as
select `moka`.`jam_kbm`.`id_kbm`   AS `id_kbm`,
       `moka`.`hari`.`nama_hari`   AS `nama_hari`,
       `moka`.`jamke`.`nama_jamke` AS `nama_jamke`
from ((`moka`.`jam_kbm` left join `moka`.`hari`
       on ((`moka`.`jam_kbm`.`id_hari` = `moka`.`hari`.`id_hari`))) left join `moka`.`jamke`
      on ((`moka`.`jam_kbm`.`id_jamke` = `moka`.`jamke`.`id_jamke`)))
order by `moka`.`jam_kbm`.`id_kbm`;

