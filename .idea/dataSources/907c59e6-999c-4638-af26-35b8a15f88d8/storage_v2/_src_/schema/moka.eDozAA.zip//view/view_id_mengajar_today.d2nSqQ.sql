create definer = root@localhost view view_id_mengajar_today as
select `moka`.`jadwal_kbm`.`id_mengajar` AS `id_mengajar`
from (`moka`.`jadwal_kbm` join `moka`.`jam_kbm` on ((`moka`.`jadwal_kbm`.`id_kbm` = `moka`.`jam_kbm`.`id_kbm`)))
where (`moka`.`jam_kbm`.`id_hari` = (select dayofweek(now())));

