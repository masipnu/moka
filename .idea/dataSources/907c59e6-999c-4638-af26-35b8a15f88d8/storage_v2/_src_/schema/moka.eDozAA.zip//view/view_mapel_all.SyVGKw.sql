create definer = root@localhost view view_mapel_all as
select `moka`.`kelas`.`id_komli`   AS `id_komli`,
       `moka`.`mapel`.`id_kelas`   AS `id_kelas`,
       `moka`.`mapel`.`id_mapel`   AS `id_mapel`,
       `moka`.`mapel`.`nama_mapel` AS `nama_mapel`,
       `moka`.`kelas`.`nama_kelas` AS `nama_kelas`,
       `moka`.`komli`.`nama_komli` AS `nama_komli`,
       `moka`.`komli`.`prosentase` AS `prosentase`
from ((`moka`.`mapel` join `moka`.`kelas`
       on ((`moka`.`mapel`.`id_kelas` = `moka`.`kelas`.`id_kelas`))) join `moka`.`komli`
      on ((`moka`.`kelas`.`id_komli` = `moka`.`komli`.`id_komli`)))
order by `moka`.`kelas`.`id_kelas`;

