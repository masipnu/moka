create definer = root@localhost view view_log_presensi_all as
select `moka`.`log_presensi`.`id_log`    AS `id_log`,
       `moka`.`log_presensi`.`tgl`       AS `tgl`,
       `moka`.`hari`.`nama_hari`         AS `nama_hari`,
       `moka`.`jamke`.`nama_jamke`       AS `nama_jamke`,
       `moka`.`mapel`.`nama_mapel`       AS `nama_mapel`,
       `moka`.`guru`.`nama`              AS `nama_guru`,
       `moka`.`siswa`.`nama`             AS `nama_siswa`,
       `moka`.`presensi`.`nama_presensi` AS `jenis_presensi`,
       `moka`.`log_presensi`.`catatan`   AS `catatan`
from (((((((((`moka`.`log_presensi` join `moka`.`mengajar`
              on ((`moka`.`log_presensi`.`id_mengajar` = `moka`.`mengajar`.`id_mengajar`))) join `moka`.`guru`
             on ((`moka`.`mengajar`.`id_guru` = `moka`.`guru`.`id_guru`))) join `moka`.`jadwal_kbm`
            on ((`moka`.`log_presensi`.`id_mengajar` = `moka`.`jadwal_kbm`.`id_mengajar`))) join `moka`.`jam_kbm`
           on ((`moka`.`jadwal_kbm`.`id_kbm` = `moka`.`jam_kbm`.`id_kbm`))) join `moka`.`hari`
          on ((`moka`.`jam_kbm`.`id_hari` = `moka`.`hari`.`id_hari`))) join `moka`.`jamke`
         on ((`moka`.`jam_kbm`.`id_jamke` = `moka`.`jamke`.`id_jamke`))) join `moka`.`mapel`
        on ((`moka`.`mengajar`.`id_mapel` = `moka`.`mapel`.`id_mapel`))) join `moka`.`siswa`
       on ((`moka`.`log_presensi`.`id_siswa` = `moka`.`siswa`.`id_siswa`))) join `moka`.`presensi`
      on ((`moka`.`log_presensi`.`id_presensi` = `moka`.`presensi`.`id_presensi`)));

