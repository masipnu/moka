create definer = root@localhost view view_mapel_sudah_ditugaskan as
select `view_mapel`.`id_mapel`         AS `id_mapel`,
       `view_mapel`.`nama_mapel`       AS `nama_mapel`,
       `view_mapel`.`nama_kelas`       AS `nama_kelas`,
       `view_mapel`.`nama_komli`       AS `nama_komli`,
       `moka`.`mengajar`.`id_mengajar` AS `id_mengajar`,
       `moka`.`mengajar`.`id_guru`     AS `id_guru`
from (`moka`.`view_mapel` join `moka`.`mengajar` on ((`view_mapel`.`id_mapel` = `moka`.`mengajar`.`id_mapel`)))
order by `view_mapel`.`nama_mapel`;

