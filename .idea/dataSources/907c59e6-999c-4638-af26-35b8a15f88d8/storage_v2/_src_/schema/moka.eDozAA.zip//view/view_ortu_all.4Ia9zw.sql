create definer = root@localhost view view_ortu_all as
select `moka`.`ortu`.`id_ortu`  AS `id_ortu`,
       `moka`.`ortu`.`nama`     AS `nama_ortu`,
       `moka`.`ortu`.`jk`       AS `jk`,
       `moka`.`ortu`.`alamat`   AS `alamat`,
       `moka`.`ortu`.`status`   AS `status`,
       `moka`.`ortu`.`no_hp`    AS `no_hp`,
       `moka`.`ortu`.`id_siswa` AS `id_siswa`,
       `moka`.`ortu`.`username` AS `username`,
       `moka`.`siswa`.`nama`    AS `nama_siswa`
from (`moka`.`ortu` join `moka`.`siswa` on ((`moka`.`ortu`.`id_siswa` = `moka`.`siswa`.`id_siswa`)));

