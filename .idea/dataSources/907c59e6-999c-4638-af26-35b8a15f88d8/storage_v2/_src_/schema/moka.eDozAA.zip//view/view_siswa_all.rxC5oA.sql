create definer = root@localhost view view_siswa_all as
select `moka`.`siswa`.`id_siswa`   AS `id_siswa`,
       `moka`.`siswa`.`foto`       AS `foto`,
       `moka`.`siswa`.`nis`        AS `nis`,
       `moka`.`siswa`.`nama`       AS `nama`,
       `moka`.`siswa`.`jk`         AS `jk`,
       `moka`.`kelas`.`id_kelas`   AS `id_kelas`,
       `moka`.`kelas`.`nama_kelas` AS `nama_kelas`,
       `moka`.`komli`.`nama_komli` AS `nama_komli`
from ((`moka`.`siswa` join `moka`.`kelas`
       on ((`moka`.`siswa`.`id_kelas` = `moka`.`kelas`.`id_kelas`))) join `moka`.`komli`
      on ((`moka`.`kelas`.`id_komli` = `moka`.`komli`.`id_komli`)))
order by `moka`.`kelas`.`nama_kelas`;

