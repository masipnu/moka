create definer = root@localhost view view_jadwal_x_pbs_rabu as
select `moka`.`jadwal_kbm`.`id_kbm`    AS `id_kbm`,
       `moka`.`jadwal_kbm`.`id_jadwal` AS `id_jadwal`,
       `moka`.`hari`.`nama_hari`       AS `nama_hari`,
       `moka`.`jamke`.`nama_jamke`     AS `nama_jamke`,
       `moka`.`mapel`.`nama_mapel`     AS `nama_mapel`,
       `moka`.`guru`.`nama`            AS `nama`
from ((((((((`moka`.`jadwal_kbm` join `moka`.`mengajar`
             on ((`moka`.`jadwal_kbm`.`id_mengajar` = `moka`.`mengajar`.`id_mengajar`))) join `moka`.`jam_kbm`
            on ((`moka`.`jadwal_kbm`.`id_kbm` = `moka`.`jam_kbm`.`id_kbm`))) join `moka`.`hari`
           on ((`moka`.`jam_kbm`.`id_hari` = `moka`.`hari`.`id_hari`))) join `moka`.`jamke`
          on ((`moka`.`jam_kbm`.`id_jamke` = `moka`.`jamke`.`id_jamke`))) join `moka`.`guru`
         on ((`moka`.`mengajar`.`id_guru` = `moka`.`guru`.`id_guru`))) join `moka`.`mapel`
        on ((`moka`.`mengajar`.`id_mapel` = `moka`.`mapel`.`id_mapel`))) join `moka`.`kelas`
       on ((`moka`.`mapel`.`id_kelas` = `moka`.`kelas`.`id_kelas`))) join `moka`.`komli`
      on ((`moka`.`kelas`.`id_komli` = `moka`.`komli`.`id_komli`)))
where ((`moka`.`kelas`.`nama_kelas` = 'X') and (`moka`.`hari`.`id_hari` = 4) and
       (`moka`.`komli`.`nama_komli` = 'Perbankan Syariah'));

