create definer = root@localhost view view_tugas_mengajar as
select `moka`.`mengajar`.`id_mengajar` AS `id_mengajar`,
       `moka`.`guru`.`nama`            AS `nama_guru`,
       `moka`.`mapel`.`nama_mapel`     AS `nama_mapel`,
       `moka`.`kelas`.`nama_kelas`     AS `nama_kelas`,
       `moka`.`komli`.`nama_komli`     AS `nama_komli`
from ((((`moka`.`mengajar` join `moka`.`guru`
         on ((`moka`.`mengajar`.`id_guru` = `moka`.`guru`.`id_guru`))) join `moka`.`mapel`
        on ((`moka`.`mengajar`.`id_mapel` = `moka`.`mapel`.`id_mapel`))) join `moka`.`kelas`
       on ((`moka`.`mapel`.`id_kelas` = `moka`.`kelas`.`id_kelas`))) join `moka`.`komli`
      on ((`moka`.`kelas`.`id_komli` = `moka`.`komli`.`id_komli`)));

