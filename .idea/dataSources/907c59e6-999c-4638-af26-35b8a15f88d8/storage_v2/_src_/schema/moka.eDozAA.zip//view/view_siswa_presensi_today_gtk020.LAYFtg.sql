create definer = root@localhost view view_siswa_presensi_today_gtk020 as
select `moka`.`siswa`.`id_siswa`       AS `id_siswa`,
       `moka`.`siswa`.`nama`           AS `nama`,
       `moka`.`siswa`.`foto`           AS `foto`,
       `moka`.`mapel`.`id_mapel`       AS `id_mapel`,
       `moka`.`mapel`.`nama_mapel`     AS `nama_mapel`,
       `moka`.`mengajar`.`id_mengajar` AS `id_mengajar`
from (((`moka`.`siswa` join `moka`.`mapel`
        on ((`moka`.`siswa`.`id_kelas` = `moka`.`mapel`.`id_kelas`))) join `moka`.`mengajar`
       on ((`moka`.`mapel`.`id_mapel` = `moka`.`mengajar`.`id_mapel`))) join `moka`.`view_id_mengajar_today`
      on ((`moka`.`mengajar`.`id_mengajar` = `view_id_mengajar_today`.`id_mengajar`)))
where (`moka`.`mengajar`.`id_guru` = 'GTK020');

