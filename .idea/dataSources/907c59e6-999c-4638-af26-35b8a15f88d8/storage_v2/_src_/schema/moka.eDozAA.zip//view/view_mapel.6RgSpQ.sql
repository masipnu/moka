create definer = root@localhost view view_mapel as
select `moka`.`mapel`.`id_mapel`   AS `id_mapel`,
       `moka`.`mapel`.`nama_mapel` AS `nama_mapel`,
       `moka`.`kelas`.`nama_kelas` AS `nama_kelas`,
       `moka`.`komli`.`nama_komli` AS `nama_komli`
from ((`moka`.`mapel` left join `moka`.`kelas`
       on ((`moka`.`mapel`.`id_kelas` = `moka`.`kelas`.`id_kelas`))) left join `moka`.`komli`
      on ((`moka`.`kelas`.`id_komli` = `moka`.`komli`.`id_komli`)))
order by `moka`.`kelas`.`id_kelas`;

