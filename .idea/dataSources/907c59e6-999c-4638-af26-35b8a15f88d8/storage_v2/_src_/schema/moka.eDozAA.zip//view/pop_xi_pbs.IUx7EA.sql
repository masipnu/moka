create definer = root@localhost view pop_xi_pbs as
select count(`moka`.`siswa`.`id_kelas`) AS `COUNT(id_kelas)`
from `moka`.`siswa`
where (`moka`.`siswa`.`id_kelas` = 14);

