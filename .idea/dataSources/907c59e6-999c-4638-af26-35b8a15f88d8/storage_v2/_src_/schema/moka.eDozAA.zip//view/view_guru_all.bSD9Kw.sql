create definer = root@localhost view view_guru_all as
select `moka`.`guru`.`id_guru`      AS `id_guru`,
       `moka`.`guru`.`nama`         AS `nama`,
       `moka`.`guru`.`gelar`        AS `gelar`,
       `moka`.`guru`.`jk`           AS `jk`,
       `moka`.`guru`.`alamat`       AS `alamat`,
       `moka`.`guru`.`tempat_lahir` AS `tempat_lahir`,
       `moka`.`guru`.`tgl_lahir`    AS `tgl_lahir`,
       `moka`.`guru`.`no_hp`        AS `no_hp`,
       `moka`.`guru`.`foto`         AS `foto`,
       `moka`.`guru`.`username`     AS `username`,
       `moka`.`guru`.`password`     AS `password`
from `moka`.`guru`
order by `moka`.`guru`.`id_guru`;

